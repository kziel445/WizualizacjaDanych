# Zadanie 1

A=[x for x in range(1,101)]
B=[x for x in A if x % 3==0]

print(B)