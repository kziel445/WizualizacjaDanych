lista=[22,33,44]
lista2=int("".join(map(str,lista)))
print(lista2)